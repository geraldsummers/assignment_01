/**
 * KIT107 Assignment 1
 *
 * Periodic Table Printer Interface
 *
 * @author J. Dermoudy
 * @version 30/7/2024
 * 
 * This file is COMPLETE.
 * 
 */

public interface PeriodicTableInterface
{
    //public PeriodicTable();
    public void printTables();
    public void printGroups();
}
